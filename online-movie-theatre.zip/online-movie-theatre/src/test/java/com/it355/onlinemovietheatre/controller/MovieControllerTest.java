package com.it355.onlinemovietheatre.controller;

import com.it355.onlinemovietheatre.entity.Director;
import com.it355.onlinemovietheatre.entity.Movie;
import com.it355.onlinemovietheatre.service.DirectorService;
import com.it355.onlinemovietheatre.service.MovieService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@SpringBootTest
@ContextConfiguration(classes = {MovieController.class})
public class MovieControllerTest {
    @MockBean
    private MovieService movieService;
    @MockBean
    private DirectorService directorService;
    @MockBean
    private Model model;
    @MockBean
    private BindingResult bindingResult;

    @Autowired
    private MovieController movieController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAddMoviePage() {
        Director director1 = new Director(1, "John", "Doe", 30, "Canada");
        Director director2 = new Director(2, "Mike", "Smith", 40, "USA");
        List<Director> directors = Arrays.asList(director1, director2);

        when(directorService.findAll()).thenReturn(directors);

        String result = movieController.getAddMoviePage(model);

        assertEquals("movie/save-movie", result);
    }

    @Test
    public void testGetUpdateMoviePage_WithExistingMovie() {
        int movieId = 1;
        Movie movie = new Movie();
        movie.setId(movieId);

        Director director = new Director();
        List<Director> directors = List.of(director);

        when(movieService.findById(movieId)).thenReturn(movie);
        when(directorService.findAll()).thenReturn(directors);

        String result = movieController.getUpdateMoviePage(movieId, model);

        assertEquals("movie/update-movie", result);
    }

    @Test
    public void testGetUpdateMoviePage_WithoutExistingMovie() {
        Director director = new Director();
        List<Director> directors = List.of(director);

        when(directorService.findAll()).thenReturn(directors);

        String result = movieController.getUpdateMoviePage(null, model);

        assertEquals("movie/update-movie", result);
    }

    @Test
    public void testGetAvailableMovies() {
        List<Movie> movies = Arrays.asList(new Movie(), new Movie());
        when(movieService.findAll()).thenReturn(movies);

        String result = movieController.getAvailableMovies(model);

        assertEquals("movie/movies", result);
        verify(model, times(1)).addAttribute("movies", movies);
    }

    @Test
    public void testSaveMovie_WithValidData() {
        int directorId = 1;
        Movie movie = new Movie();
        Director director = new Director();
        movie.setDirector(director);

        String result = movieController.saveMovie(movie, directorId, bindingResult);

        assertEquals("redirect:/movies", result);
        verify(movieService, times(1)).save(movie);
        verify(directorService, times(1)).findById(directorId);
    }

    @Test
    public void testSaveMovie_WithInvalidData() {
        int directorId = 1;
        Movie movie = new Movie();
        when(bindingResult.hasErrors()).thenReturn(true);

        assertThrows(RuntimeException.class, () -> movieController.saveMovie(movie, directorId, bindingResult));
        verify(movieService, never()).save(movie);
        verify(directorService, never()).findById(directorId);
    }

    @Test
    public void testDeleteMovie() {
        int movieId = 1;

        String result = movieController.deleteMovie(movieId);

        assertEquals("redirect:/movies", result);
        verify(movieService, times(1)).delete(movieId);
    }

    @Test
    public void testUpdateMovie_WithValidData() {
        int movieId = 1;
        int directorId = 2;
        Movie movie = new Movie();
        Director director = new Director();
        movie.setDirector(director);

        String result = movieController.updateMovie(movie, movieId, directorId, bindingResult);

        assertEquals("redirect:/movies/", result);
        verify(movieService, times(1)).updateMovie(movie, movieId, directorId);
    }

    @Test
    public void testUpdateMovie_WithInvalidData() {
        int movieId = 1;
        int directorId = 2;
        Movie movie = new Movie();
        when(bindingResult.hasErrors()).thenReturn(true);

        assertThrows(RuntimeException.class, () -> movieController.updateMovie(movie, movieId, directorId, bindingResult));
        verify(movieService, never()).updateMovie(movie, movieId, directorId);
    }
}
