package com.it355.onlinemovietheatre.service.impl;

import com.it355.onlinemovietheatre.entity.Director;
import com.it355.onlinemovietheatre.entity.Movie;
import com.it355.onlinemovietheatre.entity.enums.Genre;
import com.it355.onlinemovietheatre.repository.MovieRepository;
import com.it355.onlinemovietheatre.service.DirectorService;
import com.it355.onlinemovietheatre.service.MovieService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
@ContextConfiguration(classes = {MovieServiceImpl.class})
public class MovieServiceImplTest {
    @MockBean
    private MovieRepository movieRepository;
    @MockBean
    private DirectorService directorService;
    @Autowired
    private MovieService movieService;

    private Director director;
    private Movie movie;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        // Test data
        director = new Director();
        director.setId(1);
        director.setFirstName("John");
        director.setLastName("Doe");
        director.setAge(35);
        director.setCountry("USA");

        movie = new Movie();
        movie.setId(1);
        movie.setDirector(director);
        movie.setName("Test");
        movie.setPrice(10.99);
        movie.setImage("image.jpg");
        movie.setGenre(Genre.HORROR);
        movie.setAmount(10);
        movie.setDescription("This is a test.");
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testUpdateMovie() {
        Integer movieId = 1;
        Integer directorId = 1;

        when(movieRepository.save(movie)).thenReturn(movie);
        when(directorService.findById(directorId)).thenReturn(director);

        movie.setName("Test");
        Movie updatedMovie = movieService.updateMovie(movie, movieId, directorId);

        assertEquals(directorId, updatedMovie.getDirector().getId());
        assertEquals(movieId, updatedMovie.getId());
        assertEquals("Test", updatedMovie.getName());
    }
}