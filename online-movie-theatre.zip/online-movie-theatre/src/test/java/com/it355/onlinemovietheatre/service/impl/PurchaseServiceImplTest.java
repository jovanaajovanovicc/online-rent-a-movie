package com.it355.onlinemovietheatre.service.impl;


import com.it355.onlinemovietheatre.entity.enums.MemberType;
import com.it355.onlinemovietheatre.exception.NotEnoughMoneyException;
import com.it355.onlinemovietheatre.service.MovieService;
import com.it355.onlinemovietheatre.service.MemberService;
import com.it355.onlinemovietheatre.service.PurchaseService;
import com.it355.onlinemovietheatre.entity.*;
import com.it355.onlinemovietheatre.repository.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@SpringBootTest
@ContextConfiguration(classes = {PurchaseServiceImpl.class})
public class PurchaseServiceImplTest {
    @MockBean
    private PurchaseRepository purchaseRepository;

    @MockBean
    private MemberRepository memberRepository;

    @MockBean
    private MemberService memberService;

    @MockBean
    private MovieService movieService;

    @MockBean
    private MovieRepository movieRepository;

    @MockBean
    private CreditCardRepository creditCardRepository;

    @MockBean
    private RoleRepository roleRepository;

    @MockBean
    private UserRepository userRepository;

    @MockBean
    private DirectorRepository directorRepository;

    @Autowired
    private PurchaseService purchaseService;

    private static final String USERNAME = "test";

    Movie movie;
    Member member;
    UserEntity user;
    CreditCard creditCard;
    Role role;
    Director director;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        // Test data
        director = new Director(
                1,
                "John",
                "Doe",
                35,
                "SRB"
        );
        when(directorRepository.save(any(Director.class))).thenReturn(director);

        role = new Role(
                1,
                "USER"
        );
        when(roleRepository.save(any(Role.class))).thenReturn(role);

        creditCard = new CreditCard(
                1,
                "123",
                "Bank",
                2000.00
        );
        when(creditCardRepository.save(any(CreditCard.class))).thenReturn(creditCard);

        user = new UserEntity(
                1,
                role,
                creditCard,
                "test",
                "test"
        );
        when(userRepository.save(any(UserEntity.class))).thenReturn(user);

        movie = new Movie(
                1,
                director,
                "Test Book",
                1000.00,
                5
        );
        when(movieRepository.save(any(Movie.class))).thenReturn(movie);

        member = new Member(
                1,
                user,
                125,
                10,
                MemberType.PREMIUM
        );
        when(memberRepository.save(any(Member.class))).thenReturn(member);
    }

    @AfterEach
    public void tearDown() {
        movieRepository.deleteAll();
        memberRepository.deleteAll();
        userRepository.deleteAll();
        creditCardRepository.deleteAll();
        roleRepository.deleteAll();
        directorRepository.deleteAll();
    }

    @Test
    public void testSavePurchase_WithSufficientBalance() {
        // Create a mock Purchase object with a valid Book object
        Purchase purchase = new Purchase();
        purchase.setMovie(movie);

        // Mock the behavior of the memberService
        when(memberService.findByUserId(anyInt())).thenReturn(member);

        // Mock the behavior of the bookService
        when(movieService.findById(anyInt())).thenReturn(movie);

        // Mock the behavior of the genericRepository.save() method
        when(purchaseRepository.save(any(Purchase.class))).thenReturn(purchase);

        int initialAmount = movie.getAmount();
        double initialBalance = member.getUser().getCreditCard().getBalance();

        Purchase savedPurchase = purchaseService.savePurchase(user.getId(), movie.getId());

        assertNotNull(savedPurchase);  // Ensure that the purchase is not null

        assertEquals(initialAmount - 1, savedPurchase.getMovie().getAmount());
        double expectedPrice = movie.getPrice();
        assertEquals(initialBalance - expectedPrice, member.getUser().getCreditCard().getBalance());

        // Verify that the necessary methods were called
        verify(memberService, times(1)).findByUserId(anyInt());
        verify(movieService, times(1)).findById(anyInt());
        verify(movieService, times(1)).save(any(Movie.class));
        verify(memberService, times(1)).save(any(Member.class));
        verify(purchaseRepository, times(1)).save(any(Purchase.class));
    }


    @Test
    public void testSavePurchase_WithInsufficientBalance() {
        // Set the member's credit card balance to an insufficient amount
        member.getUser().getCreditCard().setBalance(0.0);

        // Mock the behavior of the memberService
        when(memberService.findByUserId(anyInt())).thenReturn(member);

        // Mock the behavior of the bookService
        when(movieService.findById(anyInt())).thenReturn(movie);

        assertThrows(NotEnoughMoneyException.class, () -> purchaseService.savePurchase(user.getId(), movie.getId()));

        // Verify that no changes were made
        assertEquals(5, movie.getAmount());
        assertEquals(0.0, member.getUser().getCreditCard().getBalance());

        // Verify that the necessary methods were called
        verify(memberService, times(1)).findByUserId(anyInt());
        verify(movieService, times(1)).findById(anyInt());
        verifyNoMoreInteractions(movieService);
        verifyNoMoreInteractions(memberService);
        verifyNoMoreInteractions(purchaseRepository);
    }

    @Test
    public void testFindAllByLoggedInMember() {
        // Set up the SecurityContext with the authentication
        Authentication authentication = new UsernamePasswordAuthenticationToken(USERNAME, null);
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);

        // Mock the behavior of the memberService.findByUsername() method
        when(memberService.findByUsername(USERNAME)).thenReturn(member);

        // Mock the behavior of the purchaseRepository.findAllByMemberId() method
        when(purchaseRepository.findAllByMemberId(member.getId())).thenReturn(Collections.emptyList());

        List<Purchase> purchases = purchaseService.findAllByLoggedInMember();

        assertNotNull(purchases);
        assertEquals(0, purchases.size());

        // Verify that the necessary methods were called
        verify(memberService, times(1)).findByUsername(anyString());
        verify(purchaseRepository, times(1)).findAllByMemberId(anyInt());

        // Reset the SecurityContext after the test
        SecurityContextHolder.clearContext();
    }
}
