package com.it355.onlinemovietheatre.service;

import com.it355.onlinemovietheatre.entity.Purchase;
import com.it355.onlinemovietheatre.service.generic.GenericService;

import java.util.List;

public interface PurchaseService extends GenericService<Purchase> {

    Purchase savePurchase(Integer userId, Integer bookId);

    List<Purchase> findAllByLoggedInMember();
}
