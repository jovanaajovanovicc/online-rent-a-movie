package com.it355.onlinemovietheatre.service;

import com.it355.onlinemovietheatre.entity.Member;
import com.it355.onlinemovietheatre.service.generic.GenericService;

public interface MemberService extends GenericService<Member> {

    Member findByUserId(Integer userId);

    void savePremiumMember(Integer userId);

    Member findByUsername(String username);
}
