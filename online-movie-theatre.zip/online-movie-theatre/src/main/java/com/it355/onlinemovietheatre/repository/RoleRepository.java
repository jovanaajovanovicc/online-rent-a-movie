package com.it355.onlinemovietheatre.repository;

import com.it355.onlinemovietheatre.entity.Role;
import com.it355.onlinemovietheatre.repository.abstractrep.AbstractRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RoleRepository extends AbstractRepository<Role> {
    Optional<Role> findByName(String name);
}
