package com.it355.onlinemovietheatre.service.impl;

import com.it355.onlinemovietheatre.entity.CreditCard;
import com.it355.onlinemovietheatre.entity.UserEntity;
import com.it355.onlinemovietheatre.repository.UserRepository;
import com.it355.onlinemovietheatre.repository.abstractrep.AbstractRepository;
import com.it355.onlinemovietheatre.security.SecurityUtil;
import com.it355.onlinemovietheatre.service.CreditCardService;
import com.it355.onlinemovietheatre.service.generic.impl.GenericServiceImpl;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CreditCardServiceImpl extends GenericServiceImpl<CreditCard> implements CreditCardService {

    private final UserRepository userRepository;

    protected CreditCardServiceImpl(AbstractRepository<CreditCard> abstractRepository, UserRepository userRepository) {
        super(abstractRepository);
        this.userRepository = userRepository;
    }

    @Override
    public CreditCard findByLoggedInUser() {
        String username = SecurityUtil.getSessionUser();
        Optional<UserEntity> optionalUser = userRepository.findByUsername(username);

        if (optionalUser.isPresent()) {
            UserEntity user = optionalUser.get();
            return userRepository.findById(user.getId())
                    .map(UserEntity::getCreditCard)
                    .orElse(new CreditCard());
        } else {
            return new CreditCard();
        }
    }
}
