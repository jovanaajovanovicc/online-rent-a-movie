package com.it355.onlinemovietheatre.repository;

import com.it355.onlinemovietheatre.entity.Director;
import com.it355.onlinemovietheatre.repository.abstractrep.AbstractRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DirectorRepository extends AbstractRepository<Director> {
}
