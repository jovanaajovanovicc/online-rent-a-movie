package com.it355.onlinemovietheatre.repository;

import com.it355.onlinemovietheatre.entity.CreditCard;
import com.it355.onlinemovietheatre.repository.abstractrep.AbstractRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CreditCardRepository extends AbstractRepository<CreditCard> {
}
