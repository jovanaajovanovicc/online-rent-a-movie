package com.it355.onlinemovietheatre.service.impl;

import com.it355.onlinemovietheatre.entity.Role;
import com.it355.onlinemovietheatre.repository.RoleRepository;
import com.it355.onlinemovietheatre.repository.abstractrep.AbstractRepository;
import com.it355.onlinemovietheatre.service.RoleService;
import com.it355.onlinemovietheatre.service.generic.impl.GenericServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl extends GenericServiceImpl<Role> implements RoleService {

    protected RoleServiceImpl(AbstractRepository<Role> abstractRepository) {
        super(abstractRepository);
    }

    @Override
    public Role findByName(String name) {
        return ((RoleRepository) abstractRepository).findByName(name)
                .orElseThrow(() -> new RuntimeException("Role not found"));
    }
}
