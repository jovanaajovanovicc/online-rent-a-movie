package com.it355.onlinemovietheatre.service.impl;

import com.it355.onlinemovietheatre.entity.Director;
import com.it355.onlinemovietheatre.repository.DirectorRepository;
import com.it355.onlinemovietheatre.service.DirectorService;
import com.it355.onlinemovietheatre.service.generic.impl.GenericServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class DirectorServiceImpl extends GenericServiceImpl<Director> implements DirectorService {

    protected DirectorServiceImpl(DirectorRepository directorRepository) {
        super(directorRepository);
    }
}
