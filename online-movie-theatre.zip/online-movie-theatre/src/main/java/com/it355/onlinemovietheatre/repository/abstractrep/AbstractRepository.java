package com.it355.onlinemovietheatre.repository.abstractrep;

import com.it355.onlinemovietheatre.beanannotation.Exclude;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

@Exclude
public interface AbstractRepository<T> extends JpaRepository<T, Integer>, JpaSpecificationExecutor<T> {
}

