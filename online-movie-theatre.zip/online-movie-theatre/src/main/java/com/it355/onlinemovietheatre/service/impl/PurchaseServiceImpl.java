package com.it355.onlinemovietheatre.service.impl;

import com.it355.onlinemovietheatre.entity.Movie;
import com.it355.onlinemovietheatre.entity.Member;
import com.it355.onlinemovietheatre.entity.Purchase;
import com.it355.onlinemovietheatre.entity.enums.MemberType;
import com.it355.onlinemovietheatre.exception.NotEnoughMoneyException;
import com.it355.onlinemovietheatre.repository.PurchaseRepository;
import com.it355.onlinemovietheatre.security.SecurityUtil;
import com.it355.onlinemovietheatre.service.MovieService;
import com.it355.onlinemovietheatre.service.MemberService;
import com.it355.onlinemovietheatre.service.PurchaseService;
import com.it355.onlinemovietheatre.service.generic.impl.GenericServiceImpl;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PurchaseServiceImpl extends GenericServiceImpl<Purchase> implements PurchaseService {

    private final MemberService memberService;
    private final MovieService movieService;

    protected PurchaseServiceImpl(PurchaseRepository purchaseRepository, MemberService memberService, MovieService movieService) {
        super(purchaseRepository);
        this.memberService = memberService;
        this.movieService = movieService;
    }

    @Override
    public Purchase savePurchase(Integer userId, Integer bookId) {
        Member member = memberService.findByUserId(userId);
        Movie movie = movieService.findById(bookId);

        if (member.getType() == MemberType.PREMIUM) {
            movie.setPrice(movie.getPrice() - (movie.getPrice() * member.getDiscount() / 100));
        }

        double purchasePrice = movie.getPrice();

        if (member.getUser().getCreditCard().getBalance() >= purchasePrice) {
            movie.setAmount(movie.getAmount() - 1);
            member.getUser().getCreditCard().setBalance(
                    member.getUser().getCreditCard().getBalance() - movie.getPrice()
            );

            movieService.save(movie);
            memberService.save(member);

            return abstractRepository.save(new Purchase(
                    movie,
                    member,
                    LocalDate.now(),
                    purchasePrice
            ));

        } else {
            throw new NotEnoughMoneyException();
        }
    }

    @Override
    public List<Purchase> findAllByLoggedInMember() {
        String username = SecurityUtil.getSessionUser();
        Member member = memberService.findByUsername(username);
        return ((PurchaseRepository) abstractRepository).findAllByMemberId(member.getId());
    }
}
