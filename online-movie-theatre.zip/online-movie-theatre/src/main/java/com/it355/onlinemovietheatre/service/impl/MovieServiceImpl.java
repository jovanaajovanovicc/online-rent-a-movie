package com.it355.onlinemovietheatre.service.impl;

import com.it355.onlinemovietheatre.entity.Director;
import com.it355.onlinemovietheatre.entity.Movie;
import com.it355.onlinemovietheatre.repository.MovieRepository;
import com.it355.onlinemovietheatre.service.DirectorService;
import com.it355.onlinemovietheatre.service.MovieService;
import com.it355.onlinemovietheatre.service.generic.impl.GenericServiceImpl;
import org.springframework.stereotype.Service;


@Service
public class MovieServiceImpl extends GenericServiceImpl<Movie> implements MovieService {

    private final DirectorService directorService;

    protected MovieServiceImpl(MovieRepository movieRepository, DirectorService directorService) {
        super(movieRepository);
        this.directorService = directorService;
    }

    @Override
    public Movie updateMovie(Movie movie, Integer movieId, Integer directorId) {
        Director director = directorService.findById(directorId);
        movie.setDirector(director);
        movie.setId(movieId);
        movie.setImage(movie.getImage());
        return abstractRepository.save(movie);
    }

    @Override
    public Movie saveMovie(Movie movie, Integer movieId, Integer directorId) {
        Director director = directorService.findById(directorId);
        movie.setDirector(director);
        movie.setId(movieId);
        movie.setImage(movie.getImage());
        return abstractRepository.save(movie);
    }
}
