package com.it355.onlinemovietheatre.service;

import com.it355.onlinemovietheatre.entity.Director;
import com.it355.onlinemovietheatre.service.generic.GenericService;

public interface DirectorService extends GenericService<Director> {
}
