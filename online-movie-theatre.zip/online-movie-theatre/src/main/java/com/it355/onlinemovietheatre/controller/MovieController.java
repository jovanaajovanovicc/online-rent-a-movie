package com.it355.onlinemovietheatre.controller;

import com.it355.onlinemovietheatre.entity.Director;
import com.it355.onlinemovietheatre.entity.Movie;
import com.it355.onlinemovietheatre.entity.enums.Genre;
import com.it355.onlinemovietheatre.service.DirectorService;
import com.it355.onlinemovietheatre.service.MovieService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

@Controller
@RequiredArgsConstructor
@RequestMapping("/movies")
public class MovieController {
    private final MovieService movieService;
    private final DirectorService directorService;

    // PAGES START
    @GetMapping("/add")
    public String getAddMoviePage(Model model) {
        model.addAllAttributes(Map.of(
                "movie", new Movie(),
                "directors", directorService.findAll(),
                "genres", Genre.values()
        ));
        return "movie/save-movie";
    }

    @GetMapping("/update")
    public String getUpdateMoviePage(@RequestParam(value = "movieId", required = false) Integer movieId, Model model) {
        Movie movie = movieId != null ? movieService.findById(movieId) : new Movie();

        model.addAllAttributes(Map.of(
                "movie", movie,
                "directors", directorService.findAll(),
                "genres", Genre.values()
        ));

        return "movie/update-movie";
    }

    @GetMapping("")
    public String getAvailableMovies(Model model) {
        model.addAttribute("movies", movieService.findAll());
        return "movie/movies";
    }
    // PAGES END

    @PostMapping("")
    public String saveMovie(@Valid @ModelAttribute("movie") Movie movie,
                           @RequestParam("directorId") Integer directorId,
                           BindingResult result) {
        if (result.hasErrors()) {
            throw new RuntimeException("Movie data are invalid!");
        }

        Director director = directorService.findById(directorId);
        movie.setDirector(director);

        movieService.save(movie);
        return "redirect:/movies";
    }

    @PostMapping("/delete")
    public String deleteMovie(@RequestParam("id") Integer id) {
        movieService.delete(id);
        return "redirect:/movies";
    }

    @PostMapping("/update")
    public String updateMovie(@Valid @ModelAttribute("movie") Movie movie,
                             @RequestParam("movieId") Integer movieId,
                             @RequestParam("directorId") Integer directorId,
                             BindingResult result) {
        if (result.hasErrors()) {
            throw new RuntimeException("Movie data are invalid!");
        }
        movieService.updateMovie(movie, movieId, directorId);
        return "redirect:/movies/";
    }
}
