package com.it355.onlinemovietheatre.service;

import com.it355.onlinemovietheatre.entity.Role;
import com.it355.onlinemovietheatre.service.generic.GenericService;

public interface RoleService extends GenericService<Role> {

    Role findByName(String name);
}
