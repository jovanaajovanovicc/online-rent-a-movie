package com.it355.onlinemovietheatre.entity.enums;

public enum RecordStatus {
    DELETED, ACTIVE, EXPIRED, LOCKED, DISABLED, OTHER;

    public String getValue() {
        return null;
    }
}
