package com.it355.onlinemovietheatre.repository;

import com.it355.onlinemovietheatre.entity.Purchase;
import com.it355.onlinemovietheatre.repository.abstractrep.AbstractRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PurchaseRepository extends AbstractRepository<Purchase> {
    List<Purchase> findAllByMemberId(Integer memberId);
}
