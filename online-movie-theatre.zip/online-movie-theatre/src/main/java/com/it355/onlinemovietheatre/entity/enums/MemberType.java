package com.it355.onlinemovietheatre.entity.enums;

public enum MemberType {

    STANDARD("Standard Member"),

    PREMIUM("Premium Member"),;

    private final String value;

    MemberType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
