package com.it355.onlinemovietheatre.service;

import com.it355.onlinemovietheatre.entity.CreditCard;
import com.it355.onlinemovietheatre.service.generic.GenericService;

public interface CreditCardService extends GenericService<CreditCard> {
    CreditCard findByLoggedInUser();
}
