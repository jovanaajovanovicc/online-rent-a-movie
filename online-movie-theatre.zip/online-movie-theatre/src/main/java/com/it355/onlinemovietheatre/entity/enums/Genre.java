package com.it355.onlinemovietheatre.entity.enums;

public enum Genre {
    ROMANCE("Romance"),
    HORROR("Horror"),
    THRILLER("Thriller"),
    ACTION("Action"),
    SCIFI("Science fiction"),
    COMEDY("Comedy");

    private final String value;
    Genre(String value) {

        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
