package com.it355.onlinemovietheatre.service.impl;

import com.it355.onlinemovietheatre.entity.Member;
import com.it355.onlinemovietheatre.entity.enums.MemberType;
import com.it355.onlinemovietheatre.repository.MemberRepository;
import com.it355.onlinemovietheatre.repository.abstractrep.AbstractRepository;
import com.it355.onlinemovietheatre.service.MemberService;
import com.it355.onlinemovietheatre.service.generic.impl.GenericServiceImpl;
import org.springframework.stereotype.Repository;

@Repository
public class MemberServiceImpl extends GenericServiceImpl<Member> implements MemberService {

    protected MemberServiceImpl(AbstractRepository<Member> abstractRepository) {
        super(abstractRepository);
    }

    @Override
    public Member findByUserId(Integer userId) {
        return ((MemberRepository) abstractRepository).findByUserId(userId);
    }

    @Override
    public void savePremiumMember(Integer userId) {
        Member member = findByUserId(userId);
        member.setType(MemberType.PREMIUM);
        member.setDiscount(10);
        abstractRepository.save(member);
    }

    @Override
    public Member findByUsername(String username) {
        return ((MemberRepository) abstractRepository).findByUser_Username(username);
    }
}
