package com.it355.onlinemovietheatre.service.impl;

import com.it355.onlinemovietheatre.entity.Member;
import com.it355.onlinemovietheatre.entity.Role;
import com.it355.onlinemovietheatre.entity.UserEntity;
import com.it355.onlinemovietheatre.entity.enums.MemberType;
import com.it355.onlinemovietheatre.repository.RoleRepository;
import com.it355.onlinemovietheatre.repository.UserRepository;
import com.it355.onlinemovietheatre.repository.abstractrep.AbstractRepository;
import com.it355.onlinemovietheatre.security.SecurityUtil;
import com.it355.onlinemovietheatre.service.CreditCardService;
import com.it355.onlinemovietheatre.service.MemberService;
import com.it355.onlinemovietheatre.service.UserService;
import com.it355.onlinemovietheatre.service.generic.impl.GenericServiceImpl;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends GenericServiceImpl<UserEntity> implements UserService {

    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final CreditCardService creditCardService;
    private final MemberService memberService;

    protected UserServiceImpl(AbstractRepository<UserEntity> abstractRepository, RoleRepository roleRepository, PasswordEncoder passwordEncoder, CreditCardService creditCardService, MemberService memberService) {
        super(abstractRepository);
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.creditCardService = creditCardService;
        this.memberService = memberService;
    }

    @Override
    public UserEntity findByUsername(String username) {
        return ((UserRepository) abstractRepository).findByUsername(username)
                .orElse(null);
    }

    @Override
    public UserEntity getLoggedInUser() {
        String username = SecurityUtil.getSessionUser();
        return findByUsername(username);
    }

    @Override
    public UserEntity saveUser(UserEntity user) {
        UserEntity newUser = new UserEntity();

        // set role
        Role roleUser = roleRepository.findByName(Role.USER).orElse(null);
        newUser.setRole(roleUser);

        // set credit card
        creditCardService.save(user.getCreditCard());
        newUser.setCreditCard(user.getCreditCard());

        newUser.setUsername(user.getUsername());
        newUser.setPassword(passwordEncoder.encode(user.getPassword()));
        abstractRepository.save(newUser);

        // set member
        memberService.save(new Member(
                newUser,
                newUser.getId(),
                0,
                MemberType.STANDARD
        ));

        return newUser;
    }

    @Override
    public boolean isUserAdmin() {
        return getLoggedInUser() != null && getLoggedInUser().getRole().getName().equals(Role.ADMIN);
    }
}
