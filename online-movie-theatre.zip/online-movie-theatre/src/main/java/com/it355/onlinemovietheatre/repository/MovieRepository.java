package com.it355.onlinemovietheatre.repository;

import com.it355.onlinemovietheatre.entity.Movie;
import com.it355.onlinemovietheatre.repository.abstractrep.AbstractRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MovieRepository extends AbstractRepository<Movie> {
}
