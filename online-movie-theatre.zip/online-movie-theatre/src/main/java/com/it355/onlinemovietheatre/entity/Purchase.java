package com.it355.onlinemovietheatre.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@EqualsAndHashCode(callSuper = false, onlyExplicitlyIncluded = true)
@NoArgsConstructor
@Entity
@Table(name = "purchase")
public class Purchase extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "purchase_id")
    private Integer id;

    @JoinColumn(name = "movie_fk", referencedColumnName = "movie_id")
    @ManyToOne
    private Movie movie;

    @JoinColumn(name = "member_fk", referencedColumnName = "member_id")
    @ManyToOne
    private Member member;

    @Column(name = "date")
    private LocalDate date;

    @Column(name = "price")
    private Double price;

    public Purchase(Movie movie, Member member, LocalDate date, Double price) {
        this.movie = movie;
        this.member = member;
        this.date = date;
        this.price = price;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}
