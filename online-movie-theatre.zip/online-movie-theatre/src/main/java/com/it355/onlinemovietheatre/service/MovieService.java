package com.it355.onlinemovietheatre.service;

import com.it355.onlinemovietheatre.entity.Movie;
import com.it355.onlinemovietheatre.service.generic.GenericService;


public interface MovieService extends GenericService<Movie> {

    Movie updateMovie(Movie movie, Integer movieId, Integer directorId);
    Movie saveMovie(Movie movie, Integer movieId, Integer directorId);
}
