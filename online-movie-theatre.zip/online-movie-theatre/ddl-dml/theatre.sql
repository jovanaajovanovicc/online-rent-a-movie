-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2023 at 12:43 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `theatre`
--

-- --------------------------------------------------------

--
-- Table structure for table `credit_card`
--

CREATE TABLE `credit_card` (
  `credit_card_id` int(11) NOT NULL,
  `card_number` varchar(12) NOT NULL DEFAULT '',
  `bank` varchar(128) NOT NULL,
  `balance` double NOT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_by` varchar(128) DEFAULT 'system',
  `record_status` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `credit_card`
--

INSERT INTO `credit_card` (`credit_card_id`, `card_number`, `bank`, `balance`, `created_date`, `last_modified_date`, `last_modified_by`, `record_status`) VALUES
(1, '123456789', 'UniCredit', 1550, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `director`
--

CREATE TABLE `director` (
  `director_id` int(11) NOT NULL,
  `first_name` varchar(128) NOT NULL,
  `last_name` varchar(128) NOT NULL,
  `age` int(11) NOT NULL,
  `country` varchar(64) NOT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_by` varchar(128) DEFAULT 'system',
  `record_status` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `director`
--

INSERT INTO `director` (`director_id`, `first_name`, `last_name`, `age`, `country`, `created_date`, `last_modified_date`, `last_modified_by`, `record_status`) VALUES
(1, 'Domingo ', 'González', 48, 'Spain', '2023-06-26 16:11:54', '2023-06-26 16:11:54', 'system', 1),
(2, 'James', 'Wan', 55, 'SAD', '2023-06-27 09:38:55', '2023-06-27 09:38:55', 'system', 1),
(3, 'Justin', 'Lin', 47, 'SAD', '2023-06-27 09:38:55', '2023-06-27 09:38:55', 'system', 1);

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `member_id` int(11) NOT NULL,
  `user_fk` int(11) NOT NULL,
  `member_number` int(11) NOT NULL,
  `discount` double NOT NULL,
  `type` varchar(64) NOT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_by` varchar(128) DEFAULT 'system',
  `record_status` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`member_id`, `user_fk`, `member_number`, `discount`, `type`, `created_date`, `last_modified_date`, `last_modified_by`, `record_status`) VALUES
(1, 1, 1, 10, 'PREMIUM', NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `movie_id` int(11) NOT NULL,
  `director_fk` int(11) NOT NULL,
  `name` varchar(254) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `price` double NOT NULL,
  `image` varchar(1024) DEFAULT NULL,
  `genre` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `amount` int(11) NOT NULL,
  `description` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_by` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT 'system',
  `record_status` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`movie_id`, `director_fk`, `name`, `price`, `image`, `genre`, `amount`, `description`, `created_date`, `last_modified_date`, `last_modified_by`, `record_status`) VALUES
(1, 1, 'Culpa mia', 1000, '\"https://en.wikipedia.org/wiki/My_Fault_%28film%29#/media/File:My_Fault_(film)_poster.jpg\"', 'ROMANCE', 10, 'Noah has to leave her town, boyfriend and friends behind and move into the mansion of her mother\'s new rich husband. There she meets Nick, her new stepbrother. They fall madly in love in secret.', '2023-06-26 16:14:13', '2023-06-26 16:14:13', 'system', 1),
(2, 2, 'The Conjuring', 180, '\"C:\\Users\\student\\Desktop\\online-movie-theatre\\src\\main\\resources\\templates\\images\\conj.png\"', 'HORROR', 4, 'Paranormal investigators Ed and Lorraine Warren work to help a family terrorized by a dark presence in their farmhouse', '2023-06-27 09:42:39', '2023-06-27 09:42:39', 'system', 1),
(3, 3, 'Fast & Furious', 270, 'C:\\Users\\student\\Desktop\\online-movie-theatre\\src\\main\\resources\\templates\\images\\ff.png', 'ACTION', 7, 'Brian O\'Conner, back working for the FBI in Los Angeles, teams up with Dominic Toretto to bring down a heroin importer by infiltrating his operation', '2023-06-27 09:42:39', '2023-06-27 09:42:39', 'system', 1);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `purchase_id` int(11) NOT NULL,
  `member_fk` int(11) NOT NULL,
  `movie_fk` int(11) NOT NULL,
  `date` date NOT NULL,
  `price` double NOT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_by` varchar(128) DEFAULT 'system',
  `record_status` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`purchase_id`, `member_fk`, `movie_fk`, `date`, `price`, `created_date`, `last_modified_date`, `last_modified_by`, `record_status`) VALUES
(1, 1, 2, '2023-06-27', 180, NULL, NULL, NULL, 1),
(2, 1, 3, '2023-06-27', 270, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_by` varchar(128) DEFAULT 'system',
  `record_status` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`role_id`, `name`, `created_date`, `last_modified_date`, `last_modified_by`, `record_status`) VALUES
(1, 'ADMIN', '2023-06-25 16:18:09', '2023-06-25 16:18:09', 'system', 1),
(2, 'USER', '2023-06-25 16:18:09', '2023-06-25 16:18:09', 'system', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `credit_card_fk` int(11) DEFAULT NULL,
  `role_fk` int(11) NOT NULL,
  `username` varchar(254) NOT NULL,
  `password` varchar(254) NOT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_date` timestamp NULL DEFAULT current_timestamp(),
  `last_modified_by` varchar(128) DEFAULT 'system',
  `record_status` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `credit_card_fk`, `role_fk`, `username`, `password`, `created_date`, `last_modified_date`, `last_modified_by`, `record_status`) VALUES
(1, 1, 2, 'jovana', '$2a$10$djyJJT5L3DRk1Cm.U3J6H.0IOLFLM/WZ0JJoha/Jo0B.73SZw6oR6', NULL, NULL, NULL, 1),
(3, 1, 1, 'Admin', '$2a$12$8w8JIjTi9ABdPQSx3rnP3O5Z634rnJiVwTU7DJKfu5OdW87hLSRqq', '2023-06-26 15:48:18', '2023-06-26 15:48:18', 'system', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `credit_card`
--
ALTER TABLE `credit_card`
  ADD PRIMARY KEY (`credit_card_id`),
  ADD UNIQUE KEY `card_number` (`card_number`);

--
-- Indexes for table `director`
--
ALTER TABLE `director`
  ADD PRIMARY KEY (`director_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`member_id`),
  ADD KEY `fk_member_user` (`user_fk`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`movie_id`),
  ADD KEY `fk_director_movie` (`director_fk`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`purchase_id`),
  ADD KEY `fk_purchase_movie` (`movie_fk`),
  ADD KEY `fk_purchase_member` (`member_fk`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `fk_user_credit_card` (`credit_card_fk`),
  ADD KEY `fk_user_role` (`role_fk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `credit_card`
--
ALTER TABLE `credit_card`
  MODIFY `credit_card_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `director`
--
ALTER TABLE `director`
  MODIFY `director_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
  MODIFY `movie_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `purchase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `member`
--
ALTER TABLE `member`
  ADD CONSTRAINT `fk_member_user` FOREIGN KEY (`user_fk`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `movie`
--
ALTER TABLE `movie`
  ADD CONSTRAINT `fk_director_movie` FOREIGN KEY (`director_fk`) REFERENCES `director` (`director_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchase`
--
ALTER TABLE `purchase`
  ADD CONSTRAINT `fk_purchase_member` FOREIGN KEY (`member_fk`) REFERENCES `member` (`member_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_purchase_movie` FOREIGN KEY (`movie_fk`) REFERENCES `movie` (`movie_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_user_credit_card` FOREIGN KEY (`credit_card_fk`) REFERENCES `credit_card` (`credit_card_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_role` FOREIGN KEY (`role_fk`) REFERENCES `role` (`role_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
