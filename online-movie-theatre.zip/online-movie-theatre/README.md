# Online movie theatre
This is a MVC project with Spring framework and Thymeleaf template.
